import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import CodeSpace from './components/CodeSpace';
import ExamCentre from './components/ExamCentre';
import Footer from './components/Footer';

function App() {
  return (
    <div>
      <Navbar />
      <Hero />
      <CodeSpace />
      <ExamCentre />
      <Footer />
    </div>
  );
}

export default App;
