import React from 'react';
import Typed from 'react-typed';
import image from '../assets/code.jpg';

const Analytics = () => {
  return (
    <div className='text-white px-4 py-4'>
      <div className='max-w-[1240px] mx-auto grid md:grid-cols-2'>
        <img className='w-[500px] mx-auto my-4' src={image} alt='/' />
        <div className='flex flex-col justify-center'>
          <Typed
          className='md:text-5xl sm:text-4xl text-xl font-bold md:pl-4 pl-2'
            strings={['Dive into CodeSpace']}
            typeSpeed={120}
            backSpeed={50}
            loop
          />
          <p className='px-4 py-4'>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum
            molestiae delectus culpa hic assumenda, voluptate reprehenderit
            dolore autem cum ullam sed odit perspiciatis. Doloribus quos velit,
            eveniet ex deserunt fuga?
          </p>
          <button className='bg-[#00df9a] w-[200px] rounded-md font-medium my-6 mx-auto py-3 text-black'>Get Started</button>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
